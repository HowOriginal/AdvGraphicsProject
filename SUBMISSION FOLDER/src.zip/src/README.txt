Our code was run using GLUT, on Windows 7. It is a modified version of Homework 3 from Advanced Computer Graphics that only uses the ray tracing functionality.

Code must be built using cmake.

Our scene can be run by using the command line with the following arguments:

-input ../src/txt_reflective_spheres.txt -num_threads 3 -num_antialias_samples 9 -num_shadow_samples 9 -num_bounces 3

OR

-input ../src/textured_plane_reflective_sphere.txt -num_threads 3 -num_antialias_samples 9 -num_shadow_samples 9 -num_bounces 3